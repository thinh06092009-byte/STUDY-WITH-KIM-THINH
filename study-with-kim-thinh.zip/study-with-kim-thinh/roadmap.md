# Roadmap — STUDY WITH Kim Thinh
- [x] Prompt 1 — Interface foundation (all 12 pages, VI/EN, sample data)
- [ ] Prompt 2 — Backend, accounts, roles (needs user go-ahead to enable Lovable Cloud)
- [ ] Prompt 3 — Real materials, exercises, schedule, progress
- [ ] Prompt 4 — AI study assistant
- [ ] Prompt 5 — Community, moderation, admin
- [ ] Prompt 6 — Testing and local run prep
