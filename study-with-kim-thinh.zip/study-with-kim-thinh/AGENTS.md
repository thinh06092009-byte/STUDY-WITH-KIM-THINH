<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- All UI text goes through `src/lib/i18n.tsx` (vi/en dictionaries, module store via useSyncExternalStore) — keeps both languages complete and avoids provider identity issues in SSR.
- Signed-in pages live under the pathless `_learn` layout (sidebar shell); illustrative content comes only from `src/lib/sample-data.ts` and pages show a "sample data" badge until backed by real data.
- Buttons for actions without a backend must show a "not connected yet" notice, never fake success.
