import { createFileRoute } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { Card, PageHeader, Notice } from "@/components/kit";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_learn/admin")({
  head: () => ({
    meta: [
      { title: "Quản trị — STUDY WITH Kim Thinh" },
      { name: "description", content: "Khu vực quản trị nội dung và người dùng." },
      { property: "og:title", content: "Quản trị — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Khu vực quản trị." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

function Admin() {
  const { t } = useI18n();
  const stats = [
    { label: t("adm.users"), value: "—" },
    { label: t("adm.reports"), value: "—" },
    { label: t("adm.materials"), value: "—" },
  ];
  return (
    <>
      <PageHeader title={t("nav.admin")} sub={t("adm.sub")} demo={false} />
      <Notice><Lock className="mr-2 inline h-4 w-4" />{t("adm.locked")}</Notice>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label}><div className="text-sm text-muted-foreground">{s.label}</div><div className="mt-1 font-display text-3xl font-semibold">{s.value}</div></Card>
        ))}
      </div>
    </>
  );
}
