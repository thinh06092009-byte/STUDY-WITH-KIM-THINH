import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, EmptyState, btn, Notice } from "@/components/kit";
import { SubjectFilter } from "@/components/SubjectFilter";
import { useI18n, L } from "@/lib/i18n";
import { exercises, subjects } from "@/lib/sample-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_learn/exercises")({
  head: () => ({
    meta: [
      { title: "Thư viện bài tập — STUDY WITH Kim Thinh" },
      { name: "description", content: "Luyện đề và bài tập theo độ khó, dạng đề thi THPT." },
      { property: "og:title", content: "Thư viện bài tập — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Luyện đề theo độ khó và dạng đề." },
    ],
  }),
  component: Exercises,
});

const lvl = { easy: "bg-success/15", medium: "bg-warning/20", hard: "bg-destructive/15" } as const;

function Exercises() {
  const { t, lang } = useI18n();
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("all");
  const [info, setInfo] = useState(false);
  const list = exercises.filter((e) => (subject === "all" || e.subject === subject) && L(lang, e.title).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title={t("nav.exercises")} sub={t("ex.sub")} />
      <SubjectFilter q={q} setQ={setQ} subject={subject} setSubject={setSubject} />
      {info && <div className="mb-4"><Notice>{t("notReady")}</Notice></div>}
      {list.length === 0 ? <EmptyState text={t("common.empty")} /> : (
        <div className="glass overflow-hidden rounded-2xl">
          {list.map((e) => (
            <div key={e.id} className="flex flex-wrap items-center gap-4 border-b p-4 last:border-0">
              <div className="min-w-0 flex-1">
                <div className="font-medium">{L(lang, e.title)}</div>
                <div className="text-xs text-muted-foreground">{L(lang, subjects[e.subject])} · {e.q} {t("ex.questions")} · {e.min} {t("common.minutes")}</div>
              </div>
              <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", lvl[e.level as keyof typeof lvl])}>{t(`ex.${e.level}` as "ex.easy")}</span>
              <button className={btn.outline} onClick={() => setInfo(true)}>{t("ex.start")}</button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
