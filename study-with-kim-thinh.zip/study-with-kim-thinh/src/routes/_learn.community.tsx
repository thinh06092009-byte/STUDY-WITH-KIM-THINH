import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { Card, PageHeader, btn, Notice } from "@/components/kit";
import { useI18n, L } from "@/lib/i18n";
import { posts, subjects } from "@/lib/sample-data";

export const Route = createFileRoute("/_learn/community")({
  head: () => ({
    meta: [
      { title: "Cộng đồng — STUDY WITH Kim Thinh" },
      { name: "description", content: "Hỏi đáp và chia sẻ kinh nghiệm học cùng các bạn học sinh." },
      { property: "og:title", content: "Cộng đồng — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Hỏi đáp và chia sẻ kinh nghiệm học." },
    ],
  }),
  component: Community,
});

function Community() {
  const { t, lang } = useI18n();
  const [info, setInfo] = useState(false);
  return (
    <>
      <PageHeader title={t("nav.community")} sub={t("com.sub")} action={<button className={btn.primary} onClick={() => setInfo(true)}>{t("com.new")}</button>} />
      {info && <div className="mb-4"><Notice>{t("notReady")}</Notice></div>}
      <div className="space-y-3">
        {posts.map((p) => (
          <Card key={p.id} className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary-soft font-semibold text-primary">{p.author[0]}</div>
            <div className="flex-1">
              <div className="text-xs text-muted-foreground">{p.author} · <span className="text-primary">{L(lang, subjects[p.subject])}</span></div>
              <div className="mt-1 font-medium">{L(lang, p.title)}</div>
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground"><MessageCircle className="h-4 w-4" />{p.replies}</div>
          </Card>
        ))}
      </div>
    </>
  );
}
