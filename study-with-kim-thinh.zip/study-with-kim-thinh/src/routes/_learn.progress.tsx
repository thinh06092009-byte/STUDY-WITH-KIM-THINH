import { createFileRoute } from "@tanstack/react-router";
import { Card, PageHeader, Progress } from "@/components/kit";
import { useI18n, L } from "@/lib/i18n";
import { progressBySubject, subjects } from "@/lib/sample-data";

export const Route = createFileRoute("/_learn/progress")({
  head: () => ({
    meta: [
      { title: "Tiến độ học tập — STUDY WITH Kim Thinh" },
      { name: "description", content: "Theo dõi thời gian học, số bài đã làm và độ chính xác." },
      { property: "og:title", content: "Tiến độ học tập — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Theo dõi thời gian học và kết quả." },
    ],
  }),
  component: ProgressPage,
});

const hours = [1.5, 2, 3.2, 1, 0, 4, 2.5];

function ProgressPage() {
  const { t, lang } = useI18n();
  const stats = [
    { label: t("prog.hours"), value: "14.2h" },
    { label: t("prog.done"), value: "37" },
    { label: t("prog.acc"), value: "76%" },
    { label: t("prog.streak"), value: "9" },
  ];
  const days = lang === "vi" ? ["T2", "T3", "T4", "T5", "T6", "T7", "CN"] : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return (
    <>
      <PageHeader title={t("nav.progress")} sub={t("prog.sub")} />
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}><div className="text-sm text-muted-foreground">{s.label}</div><div className="mt-1 font-display text-3xl font-semibold">{s.value}</div></Card>
        ))}
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <h2 className="mb-4 font-semibold">{t("prog.hours")}</h2>
          <div className="flex h-44 items-end gap-3">
            {hours.map((h, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div className="w-full rounded-t-md bg-primary/80" style={{ height: `${(h / 4) * 140}px` }} />
                <span className="text-xs text-muted-foreground">{days[i]}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <h2 className="mb-4 font-semibold">{t("prog.bySubject")}</h2>
          <ul className="space-y-4">
            {progressBySubject.map((p) => (
              <li key={p.subject}>
                <div className="mb-1 flex justify-between text-sm"><span>{L(lang, subjects[p.subject])}</span><span>{p.value}%</span></div>
                <Progress value={p.value} />
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
