import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, btn, Notice } from "@/components/kit";
import { useI18n, L } from "@/lib/i18n";
import { week, subjects } from "@/lib/sample-data";

export const Route = createFileRoute("/_learn/schedule")({
  head: () => ({
    meta: [
      { title: "Lịch học — STUDY WITH Kim Thinh" },
      { name: "description", content: "Lên kế hoạch và theo dõi các buổi học trong tuần." },
      { property: "og:title", content: "Lịch học — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Kế hoạch học trong tuần." },
    ],
  }),
  component: Schedule,
});

function Schedule() {
  const { t, lang } = useI18n();
  const [info, setInfo] = useState(false);
  return (
    <>
      <PageHeader title={t("nav.schedule")} sub={t("sch.sub")} action={<button className={btn.primary} onClick={() => setInfo(true)}>+ {t("sch.add")}</button>} />
      {info && <div className="mb-4"><Notice>{t("notReady")}</Notice></div>}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
        {week.map((d) => (
          <div key={d.day.en} className="glass min-h-40 rounded-2xl p-3">
            <div className="mb-3 text-center font-display font-semibold">{L(lang, d.day)}</div>
            <div className="space-y-2">
              {d.items.length === 0 && <div className="text-center text-xs text-muted-foreground">—</div>}
              {d.items.map((i) => (
                <div key={i.time} className="rounded-lg border-l-4 border-primary bg-primary-soft px-2 py-1.5 text-xs">
                  <div className="font-semibold">{i.time}</div>
                  <div>{L(lang, subjects[i.subject])}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
