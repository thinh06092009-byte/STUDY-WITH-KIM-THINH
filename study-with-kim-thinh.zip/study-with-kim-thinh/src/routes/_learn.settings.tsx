import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card, PageHeader, LangToggle, ConfirmButton, Notice } from "@/components/kit";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_learn/settings")({
  head: () => ({
    meta: [
      { title: "Cài đặt — STUDY WITH Kim Thinh" },
      { name: "description", content: "Tùy chỉnh ngôn ngữ, thông báo và tài khoản." },
      { property: "og:title", content: "Cài đặt — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Tùy chỉnh trải nghiệm học tập." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { t } = useI18n();
  const [info, setInfo] = useState(false);
  return (
    <>
      <PageHeader title={t("nav.settings")} sub={t("set.sub")} demo={false} />
      <div className="max-w-2xl space-y-4">
        <Card className="flex items-center justify-between"><span>{t("set.lang")}</span><LangToggle /></Card>
        <Card className="flex items-center justify-between">
          <span>{t("set.notif")}</span>
          <input type="checkbox" className="h-5 w-5 accent-primary" onChange={() => setInfo(true)} />
        </Card>
        {info && <Notice>{t("notReady")}</Notice>}
        <Card className="border-destructive/30">
          <h2 className="mb-3 font-semibold text-destructive">{t("set.danger")}</h2>
          <ConfirmButton label={t("set.deleteAcc")} message={t("set.confirmDel")} onConfirm={() => setInfo(true)} />
        </Card>
      </div>
    </>
  );
}
