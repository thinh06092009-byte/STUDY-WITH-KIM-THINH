import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Sparkles } from "lucide-react";
import { PageHeader, btn, Notice, inputCls } from "@/components/kit";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_learn/assistant")({
  head: () => ({
    meta: [
      { title: "Trợ lý AI — STUDY WITH Kim Thinh" },
      { name: "description", content: "Trợ lý AI giải thích bài học và gợi ý cách làm từng bước." },
      { property: "og:title", content: "Trợ lý AI — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Hỏi trợ lý AI về bài học của bạn." },
    ],
  }),
  component: Assistant,
});

function Assistant() {
  const { t } = useI18n();
  const [err, setErr] = useState(false);
  const submit = (e: FormEvent) => { e.preventDefault(); setErr(true); };
  return (
    <>
      <PageHeader title={t("nav.assistant")} sub={t("ai.sub")} demo={false} />
      <div className="glass flex h-[60vh] flex-col rounded-2xl">
        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          <div className="flex gap-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground"><Sparkles className="h-4 w-4" /></div>
            <div className="max-w-lg rounded-2xl rounded-tl-sm bg-card px-4 py-3 text-sm">{t("ai.welcome")}</div>
          </div>
        </div>
        <form onSubmit={submit} className="space-y-3 border-t p-4">
          {err && <Notice tone="error">{t("ai.disabled")}</Notice>}
          <div className="flex gap-2">
            <input className={inputCls} placeholder={t("ai.placeholder")} />
            <button className={btn.primary}>{t("ai.send")}</button>
          </div>
        </form>
      </div>
    </>
  );
}
