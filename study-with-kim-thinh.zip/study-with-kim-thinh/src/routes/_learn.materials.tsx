import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileText } from "lucide-react";
import { Card, PageHeader, EmptyState } from "@/components/kit";
import { SubjectFilter } from "@/components/SubjectFilter";
import { useI18n, L } from "@/lib/i18n";
import { materials, subjects } from "@/lib/sample-data";

export const Route = createFileRoute("/_learn/materials")({
  head: () => ({
    meta: [
      { title: "Thư viện tài liệu — STUDY WITH Kim Thinh" },
      { name: "description", content: "Tài liệu ôn thi theo môn, lớp và chuyên đề." },
      { property: "og:title", content: "Thư viện tài liệu — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Tài liệu ôn thi theo môn và chuyên đề." },
    ],
  }),
  component: Materials,
});

function Materials() {
  const { t, lang } = useI18n();
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("all");
  const list = materials.filter((m) => (subject === "all" || m.subject === subject) && L(lang, m.title).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title={t("nav.materials")} sub={t("mat.sub")} />
      <SubjectFilter q={q} setQ={setQ} subject={subject} setSubject={setSubject} />
      {list.length === 0 ? <EmptyState text={t("common.empty")} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((m) => (
            <Card key={m.id} className="flex gap-4">
              <div className="flex h-12 w-10 shrink-0 items-center justify-center rounded-md bg-primary-soft text-primary"><FileText className="h-5 w-5" /></div>
              <div>
                <div className="text-xs text-primary">{L(lang, subjects[m.subject])} · {lang === "vi" ? "Lớp" : "Grade"} {m.grade}</div>
                <div className="mt-1 font-medium leading-snug">{L(lang, m.title)}</div>
                <div className="mt-2 text-xs text-muted-foreground">{m.pages} {lang === "vi" ? "trang" : "pages"}</div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
