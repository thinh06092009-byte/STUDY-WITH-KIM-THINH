import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Clock } from "lucide-react";
import { Card, PageHeader, Progress, btn } from "@/components/kit";
import { useI18n, L } from "@/lib/i18n";
import { today, materials, progressBySubject, subjects } from "@/lib/sample-data";

export const Route = createFileRoute("/_learn/dashboard")({
  head: () => ({
    meta: [
      { title: "Tổng quan — STUDY WITH Kim Thinh" },
      { name: "description", content: "Bảng tổng quan học tập cá nhân: lịch hôm nay, tiến độ và trợ lý AI." },
      { property: "og:title", content: "Tổng quan — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Bảng tổng quan học tập cá nhân." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { t, lang } = useI18n();
  return (
    <>
      <PageHeader title={`${t("dash.hello")}, Kim Thinh 👋`} sub={t("dash.goal")} />
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h2 className="mb-4 font-semibold">{t("dash.today")}</h2>
          <ul className="space-y-3">
            {today.map((s) => (
              <li key={s.time} className="flex items-center gap-4 rounded-xl bg-card/70 p-3">
                <div className="w-14 font-display text-lg font-semibold text-primary">{s.time}</div>
                <div className="flex-1">
                  <div className="font-medium">{L(lang, s.title)}</div>
                  <div className="text-xs text-muted-foreground">{L(lang, subjects[s.subject])} · <Clock className="inline h-3 w-3" /> {s.dur} {t("common.minutes")}</div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
        <Card className="flex flex-col bg-primary-soft">
          <Sparkles className="h-6 w-6 text-primary" />
          <h2 className="mt-3 font-semibold">{t("dash.ai")}</h2>
          <p className="mt-1 flex-1 text-sm text-muted-foreground">{t("dash.aiDesc")}</p>
          <Link to="/assistant" className={`${btn.primary} mt-4`}>{t("dash.open")}</Link>
        </Card>
        <Card className="lg:col-span-2">
          <h2 className="mb-4 font-semibold">{t("dash.continue")}</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {materials.slice(0, 2).map((m, i) => (
              <Link key={m.id} to="/materials" className="rounded-xl border bg-card p-4 transition-colors hover:border-primary">
                <div className="text-xs text-primary">{L(lang, subjects[m.subject])}</div>
                <div className="mt-1 font-medium">{L(lang, m.title)}</div>
                <div className="mt-3"><Progress value={[45, 70][i] ?? 0} /></div>
              </Link>
            ))}
          </div>
        </Card>
        <Card>
          <h2 className="mb-4 font-semibold">{t("dash.progress")}</h2>
          <ul className="space-y-3">
            {progressBySubject.map((p) => (
              <li key={p.subject}>
                <div className="mb-1 flex justify-between text-sm"><span>{L(lang, subjects[p.subject])}</span><span className="text-muted-foreground">{p.value}%</span></div>
                <Progress value={p.value} />
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
