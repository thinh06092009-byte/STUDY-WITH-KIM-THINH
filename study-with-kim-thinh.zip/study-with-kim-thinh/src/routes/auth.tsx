import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Logo, LangToggle, btn, Card, Notice, inputCls } from "@/components/kit";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Đăng nhập — STUDY WITH Kim Thinh" },
      { name: "description", content: "Đăng nhập hoặc đăng ký tài khoản STUDY WITH Kim Thinh." },
      { property: "og:title", content: "Đăng nhập — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Đăng nhập hoặc đăng ký để bắt đầu học." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { t } = useI18n();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [errors, setErrors] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const errs: string[] = [];
    if (mode === "signup" && !String(f.get("name") ?? "").trim()) errs.push(t("auth.errName"));
    if (!/^\S+@\S+\.\S+$/.test(String(f.get("email") ?? ""))) errs.push(t("auth.errEmail"));
    if (String(f.get("password") ?? "").length < 8) errs.push(t("auth.errPass"));
    setErrors(errs);
    setSubmitted(errs.length === 0);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4">
      <div className="mb-6 flex w-full max-w-md items-center justify-between"><Logo /><LangToggle /></div>
      <Card className="w-full max-w-md p-7">
        <div className="mb-6 grid grid-cols-2 rounded-lg bg-muted p-1 text-sm">
          {(["login", "signup"] as const).map((m) => (
            <button key={m} onClick={() => { setMode(m); setErrors([]); setSubmitted(false); }}
              className={mode === m ? "rounded-md bg-card py-2 font-medium shadow-sm" : "py-2 text-muted-foreground"}>
              {t(m === "login" ? "auth.login" : "auth.signup")}
            </button>
          ))}
        </div>
        <form onSubmit={onSubmit} noValidate className="space-y-4">
          {mode === "signup" && (
            <label className="block text-sm">{t("auth.name")}<input name="name" className={`${inputCls} mt-1`} /></label>
          )}
          <label className="block text-sm">{t("auth.email")}<input name="email" type="email" className={`${inputCls} mt-1`} /></label>
          <label className="block text-sm">{t("auth.password")}<input name="password" type="password" className={`${inputCls} mt-1`} /></label>
          {errors.length > 0 && <Notice tone="error">{errors.map((e) => <div key={e}>{e}</div>)}</Notice>}
          {submitted && <Notice>{t("auth.pending")}</Notice>}
          <button type="submit" className={`${btn.primary} w-full`}>{t(mode === "login" ? "auth.login" : "auth.signup")}</button>
          {mode === "login" && (
            <button type="button" onClick={() => { setErrors([]); setSubmitted(true); }} className="w-full text-center text-sm text-primary hover:underline">
              {t("auth.forgot")}
            </button>
          )}
        </form>
      </Card>
    </div>
  );
}
