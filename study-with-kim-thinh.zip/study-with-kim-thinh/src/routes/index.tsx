import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, PenLine, CalendarDays, Sparkles } from "lucide-react";
import { Logo, LangToggle, btn, Card } from "@/components/kit";
import { useI18n } from "@/lib/i18n";
import hero from "@/assets/hero-study.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "STUDY WITH Kim Thinh — Ôn thi THPT & ĐGNL" },
      { name: "description", content: "Nền tảng học tập cho học sinh lớp 10–12: tài liệu, bài tập, lịch học, trợ lý AI và cộng đồng." },
      { property: "og:title", content: "STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Ôn thi THPT, ĐGNL có lộ trình và người đồng hành." },
    ],
  }),
  component: Home,
});

function Home() {
  const { t } = useI18n();
  const features = [
    { icon: BookOpen, title: t("home.f1"), desc: t("home.f1d") },
    { icon: PenLine, title: t("home.f2"), desc: t("home.f2d") },
    { icon: CalendarDays, title: t("home.f3"), desc: t("home.f3d") },
    { icon: Sparkles, title: t("home.f4"), desc: t("home.f4d") },
  ];
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <Logo />
        <div className="flex items-center gap-3">
          <LangToggle />
          <Link to="/auth" className={btn.ghost}>{t("nav.login")}</Link>
        </div>
      </header>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-10 md:grid-cols-2 md:py-16">
        <div>
          <p className="mb-3 text-sm font-medium text-primary">{t("brand.tag")}</p>
          <h1 className="text-4xl font-semibold leading-tight md:text-5xl">{t("home.title")}</h1>
          <p className="mt-5 text-lg text-muted-foreground">{t("home.sub")}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/auth" className={btn.primary}>{t("nav.start")}</Link>
            <Link to="/dashboard" className={btn.outline}>{t("nav.dashboard")}</Link>
          </div>
        </div>
        <img src={hero} alt="" width={1280} height={960} className="glass w-full rounded-3xl object-cover" />
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-4 pb-20 sm:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <Card key={f.title}>
            <f.icon className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-semibold">{f.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
          </Card>
        ))}
      </section>
    </div>
  );
}
