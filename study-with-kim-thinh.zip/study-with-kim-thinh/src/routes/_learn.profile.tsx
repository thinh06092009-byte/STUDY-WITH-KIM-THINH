import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card, PageHeader, btn, Notice, inputCls } from "@/components/kit";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_learn/profile")({
  head: () => ({
    meta: [
      { title: "Hồ sơ cá nhân — STUDY WITH Kim Thinh" },
      { name: "description", content: "Quản lý tên, cấp học và mục tiêu học tập của bạn." },
      { property: "og:title", content: "Hồ sơ cá nhân — STUDY WITH Kim Thinh" },
      { property: "og:description", content: "Thông tin cá nhân và mục tiêu học tập." },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { t, lang } = useI18n();
  const [info, setInfo] = useState(false);
  return (
    <>
      <PageHeader title={t("nav.profile")} sub={t("prof.sub")} />
      <Card className="max-w-2xl">
        <div className="mb-6 flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary font-display text-2xl text-primary-foreground">K</div>
          <div><div className="font-semibold">Kim Thinh</div><div className="text-sm text-muted-foreground">kimthinh@example.com</div></div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="text-sm">{t("auth.name")}<input defaultValue="Kim Thinh" className={`${inputCls} mt-1`} /></label>
          <label className="text-sm">{t("prof.level")}
            <select defaultValue="12" className={`${inputCls} mt-1`}>
              {["10", "11", "12"].map((g) => <option key={g} value={g}>{lang === "vi" ? "Lớp" : "Grade"} {g}</option>)}
              <option value="uni">{lang === "vi" ? "Đại học" : "University"}</option>
            </select>
          </label>
          <label className="text-sm sm:col-span-2">{t("prof.goal")}<textarea defaultValue={t("dash.goal")} rows={3} className={`${inputCls} mt-1`} /></label>
        </div>
        {info && <div className="mt-4"><Notice>{t("notReady")}</Notice></div>}
        <button className={`${btn.primary} mt-5`} onClick={() => setInfo(true)}>{t("common.save")}</button>
      </Card>
    </>
  );
}
