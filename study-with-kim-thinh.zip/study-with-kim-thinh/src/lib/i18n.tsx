import { useSyncExternalStore, type ReactNode } from "react";

export type Lang = "vi" | "en";

const dict = {
  vi: {
    "brand.tag": "Học chủ động, ôn thi hiệu quả",
    "nav.home": "Trang chủ", "nav.dashboard": "Tổng quan", "nav.materials": "Tài liệu",
    "nav.exercises": "Bài tập", "nav.schedule": "Lịch học", "nav.assistant": "Trợ lý AI",
    "nav.community": "Cộng đồng", "nav.progress": "Tiến độ", "nav.profile": "Hồ sơ",
    "nav.settings": "Cài đặt", "nav.admin": "Quản trị", "nav.login": "Đăng nhập", "nav.start": "Bắt đầu học",
    "demo": "Dữ liệu minh họa", "demo.note": "Nội dung trên trang này là dữ liệu mẫu, chưa kết nối máy chủ.",
    "notReady": "Tính năng này sẽ hoạt động sau khi kết nối máy chủ.",
    "home.title": "Ôn thi THPT, ĐGNL — có lộ trình, có người đồng hành.",
    "home.sub": "Tài liệu, bài tập, lịch học, trợ lý AI và cộng đồng trong một nơi, dành cho học sinh lớp 10–12.",
    "home.f1": "Thư viện tài liệu", "home.f1d": "Tài liệu theo môn, lớp và chuyên đề.",
    "home.f2": "Luyện đề có chấm điểm", "home.f2d": "Bài tập trắc nghiệm, tự luận theo cấu trúc đề thi.",
    "home.f3": "Lịch học cá nhân", "home.f3d": "Lên kế hoạch và theo dõi từng buổi học.",
    "home.f4": "Trợ lý AI", "home.f4d": "Giải thích khái niệm, gợi ý cách làm từng bước.",
    "auth.login": "Đăng nhập", "auth.signup": "Đăng ký", "auth.email": "Email", "auth.password": "Mật khẩu",
    "auth.name": "Tên hiển thị", "auth.forgot": "Quên mật khẩu?", "auth.noAcc": "Chưa có tài khoản?", "auth.hasAcc": "Đã có tài khoản?",
    "auth.errEmail": "Email không hợp lệ.", "auth.errPass": "Mật khẩu cần ít nhất 8 ký tự.", "auth.errName": "Vui lòng nhập tên.",
    "auth.pending": "Biểu mẫu hợp lệ, nhưng đăng nhập chưa hoạt động vì chưa kết nối máy chủ. Không có tài khoản nào được tạo.",
    "dash.hello": "Chào buổi chiều", "dash.goal": "Mục tiêu: 27+ điểm khối A00 — kỳ thi tốt nghiệp 2027",
    "dash.today": "Lịch học hôm nay", "dash.continue": "Tiếp tục học", "dash.progress": "Tiến độ tuần này",
    "dash.ai": "Hỏi trợ lý AI", "dash.aiDesc": "Bí ở một câu? Hỏi ngay để được gợi ý từng bước.", "dash.open": "Mở",
    "common.search": "Tìm kiếm...", "common.all": "Tất cả", "common.empty": "Không có kết quả phù hợp.",
    "common.retry": "Thử lại", "common.loading": "Đang tải...", "common.cancel": "Hủy", "common.confirm": "Xác nhận",
    "common.save": "Lưu thay đổi", "common.delete": "Xóa", "common.minutes": "phút",
    "mat.sub": "Tài liệu theo môn và chuyên đề.", "ex.sub": "Luyện tập theo độ khó và dạng đề.",
    "ex.easy": "Dễ", "ex.medium": "Trung bình", "ex.hard": "Khó", "ex.questions": "câu", "ex.start": "Làm bài",
    "sch.sub": "Kế hoạch học trong tuần.", "sch.add": "Thêm buổi học",
    "ai.sub": "Đặt câu hỏi về bài học của bạn.", "ai.placeholder": "Nhập câu hỏi, ví dụ: Giải thích đạo hàm hàm hợp",
    "ai.send": "Gửi", "ai.disabled": "Trợ lý AI chưa được kết nối. Câu hỏi của bạn chưa được gửi đi.",
    "ai.welcome": "Xin chào! Khi được kết nối, mình sẽ giúp bạn giải thích bài và gợi ý cách làm.",
    "com.sub": "Hỏi đáp và chia sẻ kinh nghiệm học.", "com.new": "Đăng bài", "com.replies": "trả lời",
    "prog.sub": "Theo dõi thời gian học và kết quả.", "prog.hours": "Giờ học tuần này", "prog.done": "Bài đã làm",
    "prog.acc": "Độ chính xác", "prog.streak": "Chuỗi ngày học", "prog.bySubject": "Theo môn học",
    "prof.sub": "Thông tin cá nhân của bạn.", "prof.level": "Cấp học", "prof.goal": "Mục tiêu học tập",
    "set.sub": "Tùy chỉnh trải nghiệm.", "set.lang": "Ngôn ngữ", "set.notif": "Nhắc lịch học qua email",
    "set.danger": "Vùng nguy hiểm", "set.deleteAcc": "Xóa tài khoản",
    "set.confirmDel": "Bạn chắc chắn muốn xóa tài khoản? Hành động này không thể hoàn tác.",
    "adm.sub": "Chỉ dành cho quản trị viên. Quyền sẽ được kiểm tra phía máy chủ.",
    "adm.users": "Người dùng", "adm.reports": "Báo cáo chờ xử lý", "adm.materials": "Tài liệu",
    "adm.locked": "Trang này sẽ chỉ mở cho tài khoản admin sau khi kết nối máy chủ và phân quyền.",
    "nf": "Không tìm thấy trang",
  },
  en: {
    "brand.tag": "Active learning, effective exam prep",
    "nav.home": "Home", "nav.dashboard": "Dashboard", "nav.materials": "Materials",
    "nav.exercises": "Exercises", "nav.schedule": "Schedule", "nav.assistant": "AI Assistant",
    "nav.community": "Community", "nav.progress": "Progress", "nav.profile": "Profile",
    "nav.settings": "Settings", "nav.admin": "Admin", "nav.login": "Sign in", "nav.start": "Start learning",
    "demo": "Sample data", "demo.note": "Content on this page is sample data, not yet connected to a server.",
    "notReady": "This feature will work once the server is connected.",
    "home.title": "High-school & aptitude exam prep — with a plan and a companion.",
    "home.sub": "Materials, exercises, schedule, AI assistant and community in one place, for grades 10–12.",
    "home.f1": "Material library", "home.f1d": "Resources by subject, grade and topic.",
    "home.f2": "Graded practice", "home.f2d": "Multiple-choice and written exercises in exam format.",
    "home.f3": "Personal schedule", "home.f3d": "Plan and track every study session.",
    "home.f4": "AI assistant", "home.f4d": "Explains concepts and suggests step-by-step approaches.",
    "auth.login": "Sign in", "auth.signup": "Sign up", "auth.email": "Email", "auth.password": "Password",
    "auth.name": "Display name", "auth.forgot": "Forgot password?", "auth.noAcc": "No account yet?", "auth.hasAcc": "Already have an account?",
    "auth.errEmail": "Invalid email.", "auth.errPass": "Password must be at least 8 characters.", "auth.errName": "Please enter a name.",
    "auth.pending": "The form is valid, but sign-in is not active because the server is not connected. No account was created.",
    "dash.hello": "Good afternoon", "dash.goal": "Goal: 27+ points in A00 — 2027 graduation exam",
    "dash.today": "Today's schedule", "dash.continue": "Continue learning", "dash.progress": "This week's progress",
    "dash.ai": "Ask the AI assistant", "dash.aiDesc": "Stuck on a question? Get step-by-step hints.", "dash.open": "Open",
    "common.search": "Search...", "common.all": "All", "common.empty": "No matching results.",
    "common.retry": "Retry", "common.loading": "Loading...", "common.cancel": "Cancel", "common.confirm": "Confirm",
    "common.save": "Save changes", "common.delete": "Delete", "common.minutes": "min",
    "mat.sub": "Resources by subject and topic.", "ex.sub": "Practice by difficulty and question type.",
    "ex.easy": "Easy", "ex.medium": "Medium", "ex.hard": "Hard", "ex.questions": "questions", "ex.start": "Start",
    "sch.sub": "Your study plan for the week.", "sch.add": "Add session",
    "ai.sub": "Ask questions about your lessons.", "ai.placeholder": "Type a question, e.g. Explain the chain rule",
    "ai.send": "Send", "ai.disabled": "The AI assistant is not connected yet. Your question was not sent.",
    "ai.welcome": "Hi! Once connected, I'll help explain lessons and suggest solutions.",
    "com.sub": "Q&A and study tips.", "com.new": "New post", "com.replies": "replies",
    "prog.sub": "Track study time and results.", "prog.hours": "Hours this week", "prog.done": "Exercises done",
    "prog.acc": "Accuracy", "prog.streak": "Day streak", "prog.bySubject": "By subject",
    "prof.sub": "Your personal information.", "prof.level": "Grade level", "prof.goal": "Study goal",
    "set.sub": "Customize your experience.", "set.lang": "Language", "set.notif": "Email study reminders",
    "set.danger": "Danger zone", "set.deleteAcc": "Delete account",
    "set.confirmDel": "Are you sure you want to delete your account? This cannot be undone.",
    "adm.sub": "Admins only. Permissions will be checked on the server.",
    "adm.users": "Users", "adm.reports": "Pending reports", "adm.materials": "Materials",
    "adm.locked": "This page will open only to admin accounts once the server and roles are connected.",
    "nf": "Page not found",
  },
} as const;

export type TKey = keyof (typeof dict)["vi"];

const listeners = new Set<() => void>();
let current: Lang = "vi";
let loaded = false;
function subscribe(fn: () => void) {
  listeners.add(fn);
  if (!loaded && typeof window !== "undefined") {
    loaded = true;
    const s = localStorage.getItem("lang");
    if (s === "vi" || s === "en") setLangGlobal(s);
  }
  return () => listeners.delete(fn);
}
function setLangGlobal(l: Lang) {
  current = l;
  if (typeof window !== "undefined") {
    localStorage.setItem("lang", l);
    document.documentElement.lang = l;
  }
  listeners.forEach((f) => f());
}

/** Kept for layout compatibility; language state lives in a module store. */
export function I18nProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

export function useI18n() {
  const lang = useSyncExternalStore(subscribe, () => current, () => "vi" as Lang);
  const t = (k: TKey) => dict[lang][k] ?? k;
  return { lang, setLang: setLangGlobal, t };
}

/** Pick a bilingual sample value */
export const L = (lang: Lang, v?: { vi: string; en: string }) => v?.[lang] ?? "";
