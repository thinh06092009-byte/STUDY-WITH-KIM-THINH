// SAMPLE DATA ONLY — illustrative content, replaced once the backend is connected.
type B = { vi: string; en: string };

export const subjects: Record<string, B> = {
  math: { vi: "Toán", en: "Math" },
  physics: { vi: "Vật lý", en: "Physics" },
  chem: { vi: "Hóa học", en: "Chemistry" },
  eng: { vi: "Tiếng Anh", en: "English" },
  lit: { vi: "Ngữ văn", en: "Literature" },
};

export const materials = [
  { id: 1, subject: "math", grade: 12, title: { vi: "Chuyên đề Tích phân và ứng dụng", en: "Integrals and applications" }, pages: 42 },
  { id: 2, subject: "physics", grade: 12, title: { vi: "Dao động điều hòa — tóm tắt công thức", en: "Simple harmonic motion — formula sheet" }, pages: 12 },
  { id: 3, subject: "chem", grade: 11, title: { vi: "Hidrocacbon không no", en: "Unsaturated hydrocarbons" }, pages: 28 },
  { id: 4, subject: "eng", grade: 12, title: { vi: "2000 từ vựng trọng tâm thi THPT", en: "2000 key exam vocabulary words" }, pages: 64 },
  { id: 5, subject: "lit", grade: 12, title: { vi: "Phân tích Vợ chồng A Phủ", en: "Analysis: Vo chong A Phu" }, pages: 18 },
  { id: 6, subject: "math", grade: 10, title: { vi: "Vectơ trong mặt phẳng", en: "Vectors in the plane" }, pages: 22 },
];

export const exercises = [
  { id: 1, subject: "math", level: "hard", q: 50, min: 90, title: { vi: "Đề minh họa THPT 2026 — Toán", en: "2026 sample exam — Math" } },
  { id: 2, subject: "physics", level: "medium", q: 20, min: 30, title: { vi: "Sóng cơ — luyện tập", en: "Mechanical waves — practice" } },
  { id: 3, subject: "eng", level: "easy", q: 15, min: 15, title: { vi: "Thì của động từ", en: "Verb tenses" } },
  { id: 4, subject: "chem", level: "medium", q: 25, min: 40, title: { vi: "Este — Lipit", en: "Esters — Lipids" } },
  { id: 5, subject: "math", level: "easy", q: 10, min: 20, title: { vi: "Đạo hàm cơ bản", en: "Basic derivatives" } },
];

export const today = [
  { time: "14:00", dur: 60, subject: "math", title: { vi: "Ôn tích phân từng phần", en: "Review integration by parts" } },
  { time: "16:00", dur: 45, subject: "eng", title: { vi: "Luyện đọc hiểu", en: "Reading comprehension" } },
  { time: "20:00", dur: 90, subject: "physics", title: { vi: "Giải đề dao động", en: "Oscillation problem set" } },
];

export const week: { day: B; items: { time: string; subject: string }[] }[] = [
  { day: { vi: "T2", en: "Mon" }, items: [{ time: "19:00", subject: "math" }, { time: "21:00", subject: "eng" }] },
  { day: { vi: "T3", en: "Tue" }, items: [{ time: "18:30", subject: "physics" }] },
  { day: { vi: "T4", en: "Wed" }, items: [{ time: "14:00", subject: "math" }, { time: "16:00", subject: "eng" }, { time: "20:00", subject: "physics" }] },
  { day: { vi: "T5", en: "Thu" }, items: [{ time: "19:00", subject: "chem" }] },
  { day: { vi: "T6", en: "Fri" }, items: [] },
  { day: { vi: "T7", en: "Sat" }, items: [{ time: "08:00", subject: "math" }, { time: "14:00", subject: "lit" }] },
  { day: { vi: "CN", en: "Sun" }, items: [{ time: "09:00", subject: "eng" }] },
];

export const progressBySubject = [
  { subject: "math", value: 72 },
  { subject: "physics", value: 58 },
  { subject: "chem", value: 64 },
  { subject: "eng", value: 81 },
];

export const posts = [
  { id: 1, author: "Minh Anh", subject: "math", replies: 8, title: { vi: "Mẹo nhận dạng tích phân đổi biến?", en: "Tips for spotting substitution integrals?" } },
  { id: 2, author: "Quốc Bảo", subject: "eng", replies: 3, title: { vi: "Chia sẻ lộ trình đạt 9+ Tiếng Anh", en: "My roadmap to 9+ in English" } },
  { id: 3, author: "Thu Hà", subject: "physics", replies: 12, title: { vi: "Cách nhớ công thức con lắc lò xo", en: "Remembering spring-pendulum formulas" } },
];
