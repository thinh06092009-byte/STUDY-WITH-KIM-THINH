import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export function Logo({ className }: { className?: string }) {
  return (
    <Link to="/" className={cn("font-display text-lg font-semibold tracking-tight", className)}>
      <span className="text-primary">STUDY WITH</span> <span>Kim Thinh</span>
    </Link>
  );
}

export function LangToggle() {
  const { lang, setLang } = useI18n();
  return (
    <div className="inline-flex rounded-full border bg-card p-0.5 text-xs font-medium" role="group" aria-label="Language">
      {(["vi", "en"] as const).map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "rounded-full px-3 py-1 transition-colors",
            lang === l ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {l === "vi" ? "VI" : "EN"}
        </button>
      ))}
    </div>
  );
}

const btnBase = "inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50 disabled:pointer-events-none";
export const btn = {
  primary: cn(btnBase, "bg-primary text-primary-foreground hover:bg-primary/90"),
  outline: cn(btnBase, "border bg-card text-foreground hover:bg-accent"),
  ghost: cn(btnBase, "text-foreground hover:bg-accent"),
  danger: cn(btnBase, "bg-destructive text-destructive-foreground hover:bg-destructive/90"),
};

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("glass rounded-2xl p-5", className)}>{children}</div>;
}

export function DemoBadge() {
  const { t } = useI18n();
  return (
    <span className="rounded-full border border-warning/40 bg-warning/15 px-2.5 py-0.5 text-xs font-medium text-foreground" title={t("demo.note")}>
      {t("demo")}
    </span>
  );
}

export function PageHeader({ title, sub, demo = true, action }: { title: string; sub?: string; demo?: boolean; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold md:text-3xl">{title}</h1>
          {demo && <DemoBadge />}
        </div>
        {sub && <p className="mt-1 text-muted-foreground">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Notice({ tone = "info", children }: { tone?: "info" | "error" | "success"; children: ReactNode }) {
  return (
    <div
      role="status"
      className={cn(
        "rounded-lg border px-4 py-3 text-sm",
        tone === "info" && "border-primary/30 bg-primary-soft",
        tone === "error" && "border-destructive/40 bg-destructive/10",
        tone === "success" && "border-success/40 bg-success/10",
      )}
    >
      {children}
    </div>
  );
}

export function EmptyState({ text }: { text: string }) {
  return <div className="rounded-xl border border-dashed p-10 text-center text-muted-foreground">{text}</div>;
}

export function Progress({ value }: { value: number }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
      <div className="h-full rounded-full bg-primary" style={{ width: `${value}%` }} />
    </div>
  );
}

export function ConfirmButton({ label, message, onConfirm, className }: { label: string; message: string; onConfirm: () => void; className?: string }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className={className ?? btn.danger} onClick={() => setOpen(true)}>{label}</button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/30 p-4" role="dialog" aria-modal>
          <div className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-xl">
            <p className="text-sm">{message}</p>
            <div className="mt-5 flex justify-end gap-2">
              <button className={btn.outline} onClick={() => setOpen(false)}>{t("common.cancel")}</button>
              <button className={btn.danger} onClick={() => { setOpen(false); onConfirm(); }}>{t("common.confirm")}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export const inputCls = "w-full rounded-lg border bg-card px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";
