import { cn } from "@/lib/utils";
import { useI18n, L } from "@/lib/i18n";
import { subjects } from "@/lib/sample-data";
import { inputCls } from "./kit";

export function SubjectFilter({ q, setQ, subject, setSubject }: { q: string; setQ: (v: string) => void; subject: string; setSubject: (v: string) => void }) {
  const { t, lang } = useI18n();
  const opts = ["all", ...Object.keys(subjects)];
  return (
    <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("common.search")} className={cn(inputCls, "md:max-w-xs")} />
      <div className="flex flex-wrap gap-2">
        {opts.map((s) => (
          <button key={s} onClick={() => setSubject(s)}
            className={cn("rounded-full border px-3 py-1 text-sm", subject === s ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-accent")}>
            {s === "all" ? t("common.all") : L(lang, subjects[s])}
          </button>
        ))}
      </div>
    </div>
  );
}
