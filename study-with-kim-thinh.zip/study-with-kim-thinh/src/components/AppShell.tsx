import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import {
  LayoutDashboard, BookOpen, PenLine, CalendarDays, Sparkles, Users, TrendingUp, User, Settings, Shield, Menu, X,
} from "lucide-react";
import { Logo, LangToggle } from "./kit";
import { useI18n, type TKey } from "@/lib/i18n";

const items: { to: string; key: TKey; icon: typeof BookOpen }[] = [
  { to: "/dashboard", key: "nav.dashboard", icon: LayoutDashboard },
  { to: "/materials", key: "nav.materials", icon: BookOpen },
  { to: "/exercises", key: "nav.exercises", icon: PenLine },
  { to: "/schedule", key: "nav.schedule", icon: CalendarDays },
  { to: "/assistant", key: "nav.assistant", icon: Sparkles },
  { to: "/community", key: "nav.community", icon: Users },
  { to: "/progress", key: "nav.progress", icon: TrendingUp },
  { to: "/profile", key: "nav.profile", icon: User },
  { to: "/settings", key: "nav.settings", icon: Settings },
  { to: "/admin", key: "nav.admin", icon: Shield },
];

function Nav({ onNav }: { onNav?: () => void }) {
  const { t } = useI18n();
  return (
    <nav className="flex flex-col gap-1">
      {items.map(({ to, key, icon: Icon }) => (
        <Link
          key={to}
          to={to}
          onClick={onNav}
          className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          activeProps={{ className: "!bg-primary !text-primary-foreground font-medium" }}
        >
          <Icon className="h-4 w-4" /> {t(key)}
        </Link>
      ))}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen lg:flex">
      <aside className="glass sticky top-0 hidden h-screen w-64 shrink-0 flex-col gap-6 rounded-none border-y-0 border-l-0 p-5 lg:flex">
        <Logo />
        <Nav />
        <div className="mt-auto"><LangToggle /></div>
      </aside>
      <header className="glass sticky top-0 z-40 flex items-center justify-between rounded-none border-x-0 border-t-0 px-4 py-3 lg:hidden">
        <Logo />
        <div className="flex items-center gap-2">
          <LangToggle />
          <button aria-label="Menu" onClick={() => setOpen(!open)} className="rounded-lg p-2 hover:bg-accent">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>
      {open && <div className="glass fixed inset-x-0 top-14 z-30 p-4 lg:hidden"><Nav onNav={() => setOpen(false)} /></div>}
      <main className="mx-auto w-full max-w-6xl flex-1 p-4 md:p-8">{children}</main>
    </div>
  );
}
